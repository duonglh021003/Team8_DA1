/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.duan1_n8.utilities;

import java.time.LocalDateTime;
import java.util.Calendar;

/**
 *
 * @author BXT
 */
public class test {

    public static void main(String[] args) {
        // lấy phút hiện tại
//        Calendar now = Calendar.getInstance();
//        int minute = now.get(Calendar.MINUTE);
//        System.out.println("aaaaaaaaaaaaaa" + minute);

//        LocalDateTime now = LocalDateTime.now();
//        int minute = now.getMinute();
//        System.out.println("aaaaaaaaaaaa    "+minute);
        
        //lấy giờ hiện tại
//        Calendar now = Calendar.getInstance();
//        int hour = now.get(Calendar.HOUR_OF_DAY);
//        System.out.println("aaaaaaaaa   "+hour);
        
//        LocalDateTime now = LocalDateTime.now();
//        int hour = now.getHour();
//        System.out.println("aaaaaaaaa   "+hour);

System.out.println(java.time.LocalTime.now());

    }
}
