/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.duan1_n8.application;


import com.mycompany.duan1_n8.view.GiaoDienDangNhap;


/**
 *
 * @author BuiDucMinh
 */
public class DuAn1_N8 {

    public static void main(String[] args) {
        new GiaoDienDangNhap().setVisible(true);
    }
}
